# archive workspace

archive_repository provides the release archive for example projects.

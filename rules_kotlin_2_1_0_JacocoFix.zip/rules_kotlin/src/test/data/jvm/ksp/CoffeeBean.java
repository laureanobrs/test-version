package src.test.data.jvm.ksp;

public class CoffeeBean {
    public Boolean isGood() {
        return true;
    }
}

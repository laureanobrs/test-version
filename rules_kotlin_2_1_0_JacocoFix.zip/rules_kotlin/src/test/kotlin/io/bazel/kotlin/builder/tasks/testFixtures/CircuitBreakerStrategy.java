package something;

public interface CircuitBreakerStrategy {
}

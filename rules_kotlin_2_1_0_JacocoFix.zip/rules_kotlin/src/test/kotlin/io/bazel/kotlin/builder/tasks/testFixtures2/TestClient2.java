package something;

public class TestClient2 extends Client2 {
}

package something;

public class BusConfig {
}

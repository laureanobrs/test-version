package something;

public class Client2 {
}

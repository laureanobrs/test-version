package something;

public class JavaWidgetFactory {
  public static Widget create(Client1 client1, Client2 client2) {
    return new Widget();
  }
}

package something;

public class JavaClass {
    public interface InnerJavaClass {

    }

    public static boolean staticMethod() {
        return true;
    }

    public static boolean staticMethod2() {
        return true;
    }
}
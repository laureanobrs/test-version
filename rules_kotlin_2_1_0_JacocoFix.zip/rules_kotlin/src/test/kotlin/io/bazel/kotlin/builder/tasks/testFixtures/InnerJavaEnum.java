package something;

public enum InnerJavaEnum {
    A_VALUE;
}
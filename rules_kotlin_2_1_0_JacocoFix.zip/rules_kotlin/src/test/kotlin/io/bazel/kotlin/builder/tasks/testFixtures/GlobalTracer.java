package something;

public final class GlobalTracer {
  public static Tracer get() {
    return null;
  }
}

package something;

public class Widget {
}

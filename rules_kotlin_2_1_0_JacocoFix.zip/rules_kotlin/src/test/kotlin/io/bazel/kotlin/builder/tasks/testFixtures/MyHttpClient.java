package something;

public class MyHttpClient {
    public static MyHttpClientBuilder builder() {
        return new MyHttpClientBuilder();
    }
}

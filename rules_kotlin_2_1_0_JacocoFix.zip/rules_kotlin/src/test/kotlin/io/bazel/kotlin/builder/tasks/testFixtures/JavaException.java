package something;

public class JavaException extends BaseException {
}

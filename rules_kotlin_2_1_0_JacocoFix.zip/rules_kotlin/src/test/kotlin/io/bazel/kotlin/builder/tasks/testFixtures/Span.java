package something;

public interface Span {
}

package something;

public class ConsumerConfig {
    public BusConfig getBusConfig() {
        return new BusConfig();
    }
}
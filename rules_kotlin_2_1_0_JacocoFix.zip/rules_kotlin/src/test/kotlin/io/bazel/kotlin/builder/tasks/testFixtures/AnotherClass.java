package something;

public class AnotherClass<T> {
}

package something;

interface Tracer {
  Span activeSpan();
}

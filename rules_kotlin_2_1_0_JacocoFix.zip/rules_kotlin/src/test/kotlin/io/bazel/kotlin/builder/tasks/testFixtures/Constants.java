package something;

public interface Constants {
    int HELLO_CONSTANT = 100;
}
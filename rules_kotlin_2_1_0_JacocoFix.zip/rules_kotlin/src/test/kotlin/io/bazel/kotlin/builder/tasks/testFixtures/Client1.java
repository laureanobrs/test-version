package something;

public class Client1 {
}

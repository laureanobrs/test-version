package something;

public class BaseException extends Exception {
}

package examples.deps.libKt1

class KtDummy1 {
  fun dummy() {
    System.out.println("dummy")
  }
}

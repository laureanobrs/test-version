package examples.deps.libktandroid2

class KtDummy2 {

  companion object {

    private val resourceId = R.string.dummy2;
  }

  fun dummy() {
    System.out.println("dummy")
  }
}

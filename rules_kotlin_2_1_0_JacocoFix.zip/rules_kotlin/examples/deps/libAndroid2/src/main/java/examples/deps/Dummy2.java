package examples.deps.libAndroid2;

import example.deps.libandroid2.R;

public class Dummy2 {

	private int resourceId = R.string.dummy2;
}

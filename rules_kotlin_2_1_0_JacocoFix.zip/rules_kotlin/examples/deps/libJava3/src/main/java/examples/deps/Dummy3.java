package examples.deps.libJava3;

public class Dummy3 {

  public int abiChangeVariable1 = 0;
}

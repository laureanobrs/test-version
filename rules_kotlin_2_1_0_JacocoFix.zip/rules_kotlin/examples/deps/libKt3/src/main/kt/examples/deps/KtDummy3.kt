package examples.deps.libKt3

class KtDummy3 {
  fun dummy() {
    System.out.println("dummy")
  }
}

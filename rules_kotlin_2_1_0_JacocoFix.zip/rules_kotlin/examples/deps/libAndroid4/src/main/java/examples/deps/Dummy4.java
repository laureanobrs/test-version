package examples.deps.libandroid4;

import example.deps.libandroid4.R;

public class Dummy4 {

  // Modify line below to create ABI change
  public int abiChangeVariable = 0;

  private int resourceId = R.string.dummy4;
}

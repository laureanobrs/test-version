package examples.deps.libAndroid1;

import example.deps.libandroid1.R;

public class Dummy1 {

	private int resourceId = R.string.dummy1;
}

package examples.deps.libJava1;

public class Dummy1 {}

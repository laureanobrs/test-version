package examples.deps.libktandroid3

class KtDummy3 {

  companion object {

    private val resourceId = R.string.dummy3;
  }

  fun dummy() {
    System.out.println("dummy")
  }
}

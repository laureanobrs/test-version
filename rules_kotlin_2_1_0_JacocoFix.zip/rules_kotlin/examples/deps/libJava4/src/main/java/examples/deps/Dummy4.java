package examples.deps.libJava4;

public class Dummy4 {

  // Modify line below to create ABI change
  public int abiChangeVariable = 0;
}

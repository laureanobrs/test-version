package examples.deps.libKt2

class KtDummy2 {
  fun dummy() {
    System.out.println("dummy")
  }
}

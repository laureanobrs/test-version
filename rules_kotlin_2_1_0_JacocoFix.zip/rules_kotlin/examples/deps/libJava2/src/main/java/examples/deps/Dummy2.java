package examples.deps.libJava2;

public class Dummy2 {}

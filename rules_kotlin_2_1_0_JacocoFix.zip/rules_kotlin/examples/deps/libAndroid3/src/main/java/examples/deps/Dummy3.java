package examples.deps.libAndroid3;

import example.deps.libandroid3.R;

public class Dummy3 {

	private int resourceId = R.string.dummy3;
	private int extResourceId = example.deps.libandroid4.R.string.dummy4;
}

package examples.deps.libktandroid1

class KtDummy1 {

  companion object {

    private val resourceId = R.string.dummy1;
  }

  fun dummy() {
    System.out.println("dummy")
  }
}
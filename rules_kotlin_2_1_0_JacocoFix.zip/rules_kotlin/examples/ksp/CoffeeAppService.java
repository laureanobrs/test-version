package coffee;

import com.google.auto.service.AutoService;

@AutoService(Object.class)
public class CoffeeAppService {
}

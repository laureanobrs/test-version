package examples.android.lib2

class Blargh

fun doStuff() {
  println("yay!")
  Blargh()
}

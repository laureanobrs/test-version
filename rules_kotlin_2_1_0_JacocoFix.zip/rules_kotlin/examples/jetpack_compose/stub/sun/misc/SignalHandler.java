package sun.misc;

public interface SignalHandler {
}
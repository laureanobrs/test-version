package sun.misc;

public final class Signal {
}
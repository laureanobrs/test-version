package com.foo.bar

class A1 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A2 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A3 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A4 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A5 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A6 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A7 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A8 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A9 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A10 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A11 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A12 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A13 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A14 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A15 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A16 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A17 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A18 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A19 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A20 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A21 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A22 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A23 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A24 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A25 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A26 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A27 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A28 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A29 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A30 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A31 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A32 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A33 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A34 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A35 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A36 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A37 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A38 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A39 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A40 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A41 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A42 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A43 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A44 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A45 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A46 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A47 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A48 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A49 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A50 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A51 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A52 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A53 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A54 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A55 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A56 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A57 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A58 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A59 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A60 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A61 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A62 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A63 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A64 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A65 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A66 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A67 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A68 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A69 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A70 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A71 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A72 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A73 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A74 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A75 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A76 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A77 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A78 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A79 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A80 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A81 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A82 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A83 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A84 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A85 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A86 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A87 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A88 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A89 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A90 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A91 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A92 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A93 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A94 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A95 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A96 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A97 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A98 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A99 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A100 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A101 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A102 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A103 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A104 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A105 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A106 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A107 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A108 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A109 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A110 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A111 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A112 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A113 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A114 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A115 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A116 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A117 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A118 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A119 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A120 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A121 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A122 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A123 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A124 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A125 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A126 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A127 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A128 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A129 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A130 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A131 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A132 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A133 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A134 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A135 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A136 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A137 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A138 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A139 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A140 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A141 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A142 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A143 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A144 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A145 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A146 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A147 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A148 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A149 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A150 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A151 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A152 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A153 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A154 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A155 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A156 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A157 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A158 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A159 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A160 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A161 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A162 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A163 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A164 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A165 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A166 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A167 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A168 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A169 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A170 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A171 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A172 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A173 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A174 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A175 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A176 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A177 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A178 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A179 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A180 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A181 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A182 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A183 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A184 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A185 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A186 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A187 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A188 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A189 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A190 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A191 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A192 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A193 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A194 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A195 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A196 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A197 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A198 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A199 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A200 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A201 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A202 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A203 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A204 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A205 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A206 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A207 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A208 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A209 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A210 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A211 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A212 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A213 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A214 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A215 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A216 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A217 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A218 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A219 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A220 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A221 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A222 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A223 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A224 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A225 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A226 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A227 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A228 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A229 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A230 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A231 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A232 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A233 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A234 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A235 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A236 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A237 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A238 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A239 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A240 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A241 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A242 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A243 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A244 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A245 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A246 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A247 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A248 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A249 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A250 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A251 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A252 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A253 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A254 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A255 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A256 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A257 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A258 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A259 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A260 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A261 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A262 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A263 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A264 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A265 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A266 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A267 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A268 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A269 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A270 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A271 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A272 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A273 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A274 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A275 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A276 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A277 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A278 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A279 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A280 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A281 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A282 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A283 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A284 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A285 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A286 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A287 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A288 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A289 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A290 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A291 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A292 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A293 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A294 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A295 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A296 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A297 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A298 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A299 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A300 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A301 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A302 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A303 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A304 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A305 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A306 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A307 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A308 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A309 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A310 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A311 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A312 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A313 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A314 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A315 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A316 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A317 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A318 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A319 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A320 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A321 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A322 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A323 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A324 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A325 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A326 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A327 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A328 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A329 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A330 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A331 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A332 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A333 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A334 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A335 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A336 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A337 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A338 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A339 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A340 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A341 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A342 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A343 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A344 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A345 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A346 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A347 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A348 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A349 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A350 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A351 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A352 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A353 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A354 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A355 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A356 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A357 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A358 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A359 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A360 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A361 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A362 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A363 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A364 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A365 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A366 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A367 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A368 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A369 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A370 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A371 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A372 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A373 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A374 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A375 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A376 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A377 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A378 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A379 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A380 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A381 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A382 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A383 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A384 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A385 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A386 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A387 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A388 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A389 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A390 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A391 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A392 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A393 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A394 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A395 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A396 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A397 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A398 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A399 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A400 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A401 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A402 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A403 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A404 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A405 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A406 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A407 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A408 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A409 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A410 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A411 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A412 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A413 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A414 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A415 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A416 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A417 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A418 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A419 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A420 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A421 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A422 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A423 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A424 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A425 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A426 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A427 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A428 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A429 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A430 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A431 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A432 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A433 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A434 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A435 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A436 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A437 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A438 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A439 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A440 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A441 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A442 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A443 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A444 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A445 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A446 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A447 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A448 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A449 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A450 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A451 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A452 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A453 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A454 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A455 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A456 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A457 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A458 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A459 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A460 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A461 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A462 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A463 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A464 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A465 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A466 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A467 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A468 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A469 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A470 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A471 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A472 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A473 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A474 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A475 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A476 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A477 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A478 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A479 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A480 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A481 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A482 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A483 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A484 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A485 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A486 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A487 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A488 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A489 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A490 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A491 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A492 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A493 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A494 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A495 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A496 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A497 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A498 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A499 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A500 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A501 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A502 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A503 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A504 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A505 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A506 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A507 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A508 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A509 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A510 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A511 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A512 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A513 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A514 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A515 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A516 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A517 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A518 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A519 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A520 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A521 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A522 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A523 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A524 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A525 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A526 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A527 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A528 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A529 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A530 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A531 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A532 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A533 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A534 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A535 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A536 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A537 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A538 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A539 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A540 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A541 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A542 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A543 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A544 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A545 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A546 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A547 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A548 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A549 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A550 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A551 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A552 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A553 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A554 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A555 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A556 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A557 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A558 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A559 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A560 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A561 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A562 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A563 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A564 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A565 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A566 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A567 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A568 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A569 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A570 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A571 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A572 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A573 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A574 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A575 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A576 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A577 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A578 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A579 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A580 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A581 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A582 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A583 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A584 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A585 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A586 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A587 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A588 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A589 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A590 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A591 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A592 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A593 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A594 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A595 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A596 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A597 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A598 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A599 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A600 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A601 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A602 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A603 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A604 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A605 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A606 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A607 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A608 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A609 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A610 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A611 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A612 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A613 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A614 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A615 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A616 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A617 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A618 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A619 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A620 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A621 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A622 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A623 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A624 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A625 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A626 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A627 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A628 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A629 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A630 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A631 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A632 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A633 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A634 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A635 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A636 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A637 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A638 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A639 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A640 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A641 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A642 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A643 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A644 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A645 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A646 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A647 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A648 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A649 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A650 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A651 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A652 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A653 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A654 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A655 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A656 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A657 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A658 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A659 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A660 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A661 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A662 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A663 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A664 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A665 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A666 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A667 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A668 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A669 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A670 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A671 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A672 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A673 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A674 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A675 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A676 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A677 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A678 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A679 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A680 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A681 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A682 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A683 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A684 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A685 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A686 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A687 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A688 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A689 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A690 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A691 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A692 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A693 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A694 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A695 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A696 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A697 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A698 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A699 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A700 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A701 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A702 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A703 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A704 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A705 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A706 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A707 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A708 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A709 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A710 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A711 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A712 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A713 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A714 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A715 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A716 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A717 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A718 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A719 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A720 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A721 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A722 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A723 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A724 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A725 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A726 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A727 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A728 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A729 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A730 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A731 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A732 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A733 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A734 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A735 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A736 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A737 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A738 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A739 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A740 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A741 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A742 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A743 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A744 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A745 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A746 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A747 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A748 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A749 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A750 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A751 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A752 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A753 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A754 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A755 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A756 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A757 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A758 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A759 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A760 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A761 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A762 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A763 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A764 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A765 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A766 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A767 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A768 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A769 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A770 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A771 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A772 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A773 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A774 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A775 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A776 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A777 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A778 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A779 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A780 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A781 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A782 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A783 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A784 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A785 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A786 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A787 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A788 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A789 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A790 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A791 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A792 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A793 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A794 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A795 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A796 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A797 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A798 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A799 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A800 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A801 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A802 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A803 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A804 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A805 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A806 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A807 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A808 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A809 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A810 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A811 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A812 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A813 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A814 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A815 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A816 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A817 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A818 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A819 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A820 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A821 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A822 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A823 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A824 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A825 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A826 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A827 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A828 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A829 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A830 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A831 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A832 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A833 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A834 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A835 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A836 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A837 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A838 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A839 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A840 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A841 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A842 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A843 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A844 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A845 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A846 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A847 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A848 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A849 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A850 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A851 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A852 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A853 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A854 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A855 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A856 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A857 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A858 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A859 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A860 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A861 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A862 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A863 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A864 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A865 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A866 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A867 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A868 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A869 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A870 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A871 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A872 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A873 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A874 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A875 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A876 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A877 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A878 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A879 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A880 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A881 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A882 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A883 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A884 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A885 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A886 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A887 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A888 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A889 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A890 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A891 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A892 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A893 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A894 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A895 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A896 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A897 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A898 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A899 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A900 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A901 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A902 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A903 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A904 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A905 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A906 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A907 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A908 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A909 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A910 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A911 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A912 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A913 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A914 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A915 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A916 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A917 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A918 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A919 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A920 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A921 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A922 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A923 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A924 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A925 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A926 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A927 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A928 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A929 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A930 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A931 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A932 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A933 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A934 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A935 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A936 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A937 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A938 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A939 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A940 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A941 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A942 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A943 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A944 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A945 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A946 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A947 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A948 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A949 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A950 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A951 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A952 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A953 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A954 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A955 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A956 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A957 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A958 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A959 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A960 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A961 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A962 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A963 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A964 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A965 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A966 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A967 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A968 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A969 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A970 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A971 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A972 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A973 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A974 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A975 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A976 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A977 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A978 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A979 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A980 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A981 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A982 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A983 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A984 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A985 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A986 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A987 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A988 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A989 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A990 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A991 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A992 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A993 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A994 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A995 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A996 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A997 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A998 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A999 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1000 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1001 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1002 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1003 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1004 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1005 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1006 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1007 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1008 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1009 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1010 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1011 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1012 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1013 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1014 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1015 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1016 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1017 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1018 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1019 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1020 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1021 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1022 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1023 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1024 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1025 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1026 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1027 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1028 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1029 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1030 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1031 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1032 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1033 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1034 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1035 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1036 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1037 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1038 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1039 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1040 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1041 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1042 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1043 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1044 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1045 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1046 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1047 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1048 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1049 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1050 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1051 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1052 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1053 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1054 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1055 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1056 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1057 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1058 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1059 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1060 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1061 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1062 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1063 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1064 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1065 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1066 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1067 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1068 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1069 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1070 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1071 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1072 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1073 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1074 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1075 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1076 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1077 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1078 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1079 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1080 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1081 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1082 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1083 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1084 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1085 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1086 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1087 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1088 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1089 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1090 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1091 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1092 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1093 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1094 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1095 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1096 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1097 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1098 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1099 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1100 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1101 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1102 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1103 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1104 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1105 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1106 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1107 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1108 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1109 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1110 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1111 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1112 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1113 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1114 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1115 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1116 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1117 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1118 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1119 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1120 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1121 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1122 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1123 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1124 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1125 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1126 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1127 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1128 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1129 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1130 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1131 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1132 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1133 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1134 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1135 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1136 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1137 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1138 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1139 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1140 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1141 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1142 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1143 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1144 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1145 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1146 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1147 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1148 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1149 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1150 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1151 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1152 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1153 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1154 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1155 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1156 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1157 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1158 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1159 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1160 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1161 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1162 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1163 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1164 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1165 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1166 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1167 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1168 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1169 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1170 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1171 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1172 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1173 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1174 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1175 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1176 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1177 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1178 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1179 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1180 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1181 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1182 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1183 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1184 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1185 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1186 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1187 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1188 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1189 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1190 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1191 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1192 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1193 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1194 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1195 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1196 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1197 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1198 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1199 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1200 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1201 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1202 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1203 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1204 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1205 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1206 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1207 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1208 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1209 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1210 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1211 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1212 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1213 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1214 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1215 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1216 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1217 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1218 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1219 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1220 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1221 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1222 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1223 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1224 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1225 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1226 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1227 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1228 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1229 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1230 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1231 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1232 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1233 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1234 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1235 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1236 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1237 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1238 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1239 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1240 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1241 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1242 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1243 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1244 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1245 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1246 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1247 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1248 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1249 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1250 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1251 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1252 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1253 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1254 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1255 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1256 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1257 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1258 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1259 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1260 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1261 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1262 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1263 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1264 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1265 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1266 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1267 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1268 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1269 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1270 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1271 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1272 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1273 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1274 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1275 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1276 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1277 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1278 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1279 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1280 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1281 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1282 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1283 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1284 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1285 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1286 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1287 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1288 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1289 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1290 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1291 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1292 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1293 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1294 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1295 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1296 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1297 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1298 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1299 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1300 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1301 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1302 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1303 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1304 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1305 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1306 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1307 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1308 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1309 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1310 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1311 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1312 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1313 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1314 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1315 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1316 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1317 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1318 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1319 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1320 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1321 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1322 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1323 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1324 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1325 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1326 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1327 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1328 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1329 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1330 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1331 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1332 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1333 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1334 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1335 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1336 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1337 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1338 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1339 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1340 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1341 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1342 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1343 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1344 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1345 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1346 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1347 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1348 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1349 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1350 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1351 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1352 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1353 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1354 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1355 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1356 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1357 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1358 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1359 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1360 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1361 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1362 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1363 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1364 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1365 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1366 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1367 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1368 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1369 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1370 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1371 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1372 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1373 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1374 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1375 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1376 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1377 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1378 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1379 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1380 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1381 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1382 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1383 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1384 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1385 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1386 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1387 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1388 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1389 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1390 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1391 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1392 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1393 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1394 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1395 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1396 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1397 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1398 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1399 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1400 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1401 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1402 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1403 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1404 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1405 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1406 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1407 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1408 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1409 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1410 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1411 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1412 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1413 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1414 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1415 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1416 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1417 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1418 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1419 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1420 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1421 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1422 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1423 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1424 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1425 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1426 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1427 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1428 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1429 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1430 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1431 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1432 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1433 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1434 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1435 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1436 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1437 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1438 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1439 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1440 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1441 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1442 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1443 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1444 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1445 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1446 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1447 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1448 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1449 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1450 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1451 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1452 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1453 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1454 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1455 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1456 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1457 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1458 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1459 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1460 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1461 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1462 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1463 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1464 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1465 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1466 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1467 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1468 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1469 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1470 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1471 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1472 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1473 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1474 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1475 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1476 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1477 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1478 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1479 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1480 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1481 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1482 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1483 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1484 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1485 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1486 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1487 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1488 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1489 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1490 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1491 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1492 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1493 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1494 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1495 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1496 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1497 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1498 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1499 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1500 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1501 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1502 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1503 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1504 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1505 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1506 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1507 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1508 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1509 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1510 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1511 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1512 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1513 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1514 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1515 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1516 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1517 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1518 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1519 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1520 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1521 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1522 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1523 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1524 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1525 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1526 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1527 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1528 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1529 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1530 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1531 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1532 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1533 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1534 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1535 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1536 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1537 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1538 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1539 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1540 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1541 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1542 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1543 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1544 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1545 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1546 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1547 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1548 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1549 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1550 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1551 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1552 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1553 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1554 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1555 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1556 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1557 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1558 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1559 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1560 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1561 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1562 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1563 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1564 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1565 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1566 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1567 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1568 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1569 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1570 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1571 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1572 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1573 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1574 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1575 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1576 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1577 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1578 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1579 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1580 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1581 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1582 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1583 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1584 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1585 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1586 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1587 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1588 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1589 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1590 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1591 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1592 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1593 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1594 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1595 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1596 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1597 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1598 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1599 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1600 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1601 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1602 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1603 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1604 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1605 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1606 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1607 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1608 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1609 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1610 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1611 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1612 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1613 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1614 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1615 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1616 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1617 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1618 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1619 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1620 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1621 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1622 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1623 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1624 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1625 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1626 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1627 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1628 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1629 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1630 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1631 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1632 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1633 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1634 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1635 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1636 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1637 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1638 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1639 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1640 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1641 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1642 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1643 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1644 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1645 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1646 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1647 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1648 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1649 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1650 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1651 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1652 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1653 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1654 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1655 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1656 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1657 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1658 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1659 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1660 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1661 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1662 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1663 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1664 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1665 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1666 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1667 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1668 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1669 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1670 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1671 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1672 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1673 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1674 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1675 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1676 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1677 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1678 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1679 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1680 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1681 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1682 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1683 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1684 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1685 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1686 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1687 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1688 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1689 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1690 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1691 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1692 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1693 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1694 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1695 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1696 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1697 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1698 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1699 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1700 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1701 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1702 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1703 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1704 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1705 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1706 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1707 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1708 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1709 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1710 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1711 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1712 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1713 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1714 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1715 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1716 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1717 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1718 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1719 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1720 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1721 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1722 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1723 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1724 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1725 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1726 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1727 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1728 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1729 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1730 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1731 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1732 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1733 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1734 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1735 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1736 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1737 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1738 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1739 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1740 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1741 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1742 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1743 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1744 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1745 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1746 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1747 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1748 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1749 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1750 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1751 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1752 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1753 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1754 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1755 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1756 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1757 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1758 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1759 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1760 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1761 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1762 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1763 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1764 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1765 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1766 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1767 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1768 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1769 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1770 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1771 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1772 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1773 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1774 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1775 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1776 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1777 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1778 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1779 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1780 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1781 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1782 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1783 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1784 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1785 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1786 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1787 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1788 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1789 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1790 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1791 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1792 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1793 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1794 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1795 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1796 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1797 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1798 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1799 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1800 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1801 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1802 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1803 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1804 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1805 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1806 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1807 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1808 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1809 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1810 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1811 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1812 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1813 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1814 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1815 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1816 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1817 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1818 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1819 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1820 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1821 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1822 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1823 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1824 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1825 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1826 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1827 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1828 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1829 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1830 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1831 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1832 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1833 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1834 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1835 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1836 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1837 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1838 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1839 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1840 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1841 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1842 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1843 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1844 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1845 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1846 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1847 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1848 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1849 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1850 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1851 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1852 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1853 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1854 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1855 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1856 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1857 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1858 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1859 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1860 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1861 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1862 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1863 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1864 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1865 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1866 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1867 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1868 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1869 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1870 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1871 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1872 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1873 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1874 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1875 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1876 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1877 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1878 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1879 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1880 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1881 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1882 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1883 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1884 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1885 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1886 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1887 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1888 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1889 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1890 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1891 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1892 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1893 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1894 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1895 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1896 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1897 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1898 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1899 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1900 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1901 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1902 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1903 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1904 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1905 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1906 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1907 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1908 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1909 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1910 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1911 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1912 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1913 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1914 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1915 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1916 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1917 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1918 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1919 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1920 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1921 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1922 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1923 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1924 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1925 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1926 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1927 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1928 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1929 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1930 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1931 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1932 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1933 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1934 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1935 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1936 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1937 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1938 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1939 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1940 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1941 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1942 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1943 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1944 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1945 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1946 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1947 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1948 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1949 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1950 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1951 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1952 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1953 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1954 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1955 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1956 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1957 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1958 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1959 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1960 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1961 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1962 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1963 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1964 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1965 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1966 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1967 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1968 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1969 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1970 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1971 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1972 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1973 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1974 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1975 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1976 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1977 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1978 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1979 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1980 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1981 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1982 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1983 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1984 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1985 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1986 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1987 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1988 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1989 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1990 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1991 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1992 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1993 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1994 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1995 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1996 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1997 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1998 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


class A1999 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}



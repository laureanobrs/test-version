
package com.foo.bar

class E1 {
    fun a1(a: Int, b: Int) = a + b
    fun a2(a: Int, b: Int) = a + b
    fun a3(a: Int, b: Int) = a + b
    fun a4(a: Int, b: Int) = a + b
    fun a5(a: Int, b: Int) = a + b
    fun a6(a: Int, b: Int) = a + b
    fun a7(a: Int, b: Int) = a + b
    fun a8(a: Int, b: Int) = a + b
    fun a9(a: Int, b: Int) = a + b
    fun a10(a: Int, b: Int) = a + b
}


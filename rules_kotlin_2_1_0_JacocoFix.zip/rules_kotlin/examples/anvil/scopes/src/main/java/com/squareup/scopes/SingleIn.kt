package com.squareup.scopes

import kotlin.reflect.KClass

annotation class SingleIn(val clazz: KClass<*>)

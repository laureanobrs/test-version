package com.squareup.scopes

abstract class LoggedInScope private constructor()

package com.squareup.scopes

abstract class AppScope private constructor()

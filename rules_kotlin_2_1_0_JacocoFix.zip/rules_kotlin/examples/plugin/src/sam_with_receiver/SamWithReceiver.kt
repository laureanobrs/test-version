package plugin.sam_with_receiver

annotation class SamWithReceiver

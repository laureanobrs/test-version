package plugin.sam_with_receiver;

@SamWithReceiver
public interface Runner {
    void run(Double shouldBecomeThis);
}

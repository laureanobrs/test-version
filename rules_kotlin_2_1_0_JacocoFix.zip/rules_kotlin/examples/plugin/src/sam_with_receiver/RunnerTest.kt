package plugin.sam_with_receiver

val thisShouldWork = Runner {
  println(this.isFinite())
}

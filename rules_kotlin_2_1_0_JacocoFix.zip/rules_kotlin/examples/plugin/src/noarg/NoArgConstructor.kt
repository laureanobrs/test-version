package plugin.noarg

annotation class NoArgConstructor

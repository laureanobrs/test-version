package plugin.allopennoarg

annotation class OpenForTesting

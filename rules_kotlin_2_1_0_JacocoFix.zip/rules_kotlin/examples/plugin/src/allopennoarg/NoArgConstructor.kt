package plugin.allopennoarg

annotation class NoArgConstructor

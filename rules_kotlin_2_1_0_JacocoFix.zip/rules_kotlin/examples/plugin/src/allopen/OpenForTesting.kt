package plugin.allopen

annotation class OpenForTesting
